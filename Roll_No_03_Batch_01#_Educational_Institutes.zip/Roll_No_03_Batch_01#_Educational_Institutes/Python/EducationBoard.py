#Author Name:-Adnan M.Shaikh
#Roll No:-03
#Displaying The Details Of Various Boards
#Start Date:-17/07/2024
#Modified Date:-24/07/2024
#Description:- To Find Classes and objects in the institutions Website and this is a code written to display the Various Boards By Taki9ng input from the user.
class EducationBoard:
    def __init__(self, name, established_date, resolution_number, gazette_notification_date):
        self.name = name
        self.established_date = established_date
        self.resolution_number = resolution_number
        self.gazette_notification_date = gazette_notification_date

    def get_board_info(self):
        print(f"Name: {self.name}")
        print(f"Established Date: {self.established_date}")
        print(f"Resolution Number: {self.resolution_number}")
        print(f"Gazette Notification Date: {self.gazette_notification_date}")

class NationalBoard(EducationBoard):
    def __init__(self, name, established_date, resolution_number, gazette_notification_date, recognition_date, approved_by):
        super().__init__(name, established_date, resolution_number, gazette_notification_date)
        self.recognition_date = recognition_date
        self.approved_by = approved_by

    def get_national_board_info(self):
        self.get_board_info()
        print(f"Recognition Date: {self.recognition_date}")
        print(f"Approved By: {self.approved_by}")

class SchoolBoard(EducationBoard):
    def __init__(self, name, established_date, resolution_number, gazette_notification_date, associated_ministry, rules):
        super()._init_(name, established_date, resolution_number, gazette_notification_date)
        self.associated_ministry = associated_ministry
        self.rules = rules

    def get_school_board_info(self):
        self.get_board_info()
        print(f"Associated Ministry: {self.associated_ministry}")
        print(f"Rules: {self.rules}")

def main():
    print("Choose an education board:")
    print("1. National Board")
    print("2. School Board")

    choice = input("Enter your choice (1 or 2): ")

    if choice == '1':
        cbse = NationalBoard(
            "Central Board of Secondary Education (CBSE)",
            "01.07.1929",
            "F-115-R/28",
            "11.11.1929",
            "20.10.1990",
            "Ministry _of Education"
        )
        cbse.get_national_board_info()
    elif choice == '2':
        msrvvp = SchoolBoard(
            "Maharshi Sandipani Rashtriya Veda Sanskrit Shiksha Board, Ujjain",
            "08.08.2022",
            "Rule 14(iv) (f)",
            "25.01.2023",
            "Department of Higher Education",
            "MoA of MSRVVP"
        )
        msrvvp.get_school_board_info()
    else:
        print("Invalid choice. Please enter either 1 or 2.")

if __name__ == "__main__":
    main()