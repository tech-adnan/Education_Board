// Author Name: Adnan Shaikh
// Roll No: 03
// Displaying The Details Of Various Boards
// Start Date: 17/07/2024
// Modified Date: 24/07/2024
// Description: This program finds classes and objects in the institution's website and is written to display various boards by taking input from the user.
// Comments are also Created for the below code to Generate Javadoc

import java.util.Scanner;

/**
 * The NationalBoard class represents a national-level educational board.
 * It extends the EducationBoard class to include additional details specific to national boards.
 */
class NationalBoard extends EducationBoard {
    /**
     * Recognition Date
     * <p>Date when the board was recognized.</p>
     * */
    public String recognitionDate;
    /**
     * Authority's Approval
     * <p>Authority that approved the board.</p>
     * */
    public String approvedBy;

    /**
     * Constructor to initialize the NationalBoard with its specific attributes.
     *
     * @param name                    The name of the national board
     * @param establishedDate         The date the board was established
     * @param resolutionNumber        The resolution number for the board's establishment
     * @param gazetteNotificationDate The date the board was notified in the gazette
     * @param recognitionDate         The date the board was recognized
     * @param approvedBy              The authority that approved the board
     */
    public NationalBoard(String name, String establishedDate, String resolutionNumber, String gazetteNotificationDate, String recognitionDate, String approvedBy) {
        super(name, establishedDate, resolutionNumber, gazetteNotificationDate);
        this.recognitionDate = recognitionDate;
        this.approvedBy = approvedBy;
    }

    /**
     * Gets the recognition date of the national board.
     * ------------------------------
     * @return The recognition date
     */
    public String getRecognitionDate() {
        return recognitionDate;
    }

    /**
     * Gets the authority that approved the national board.
     *
     * @return The approving authority
     */
    public String getApprovedBy() {
        return approvedBy;
    }

    /**
     * Displays the information specific to the national board including inherited information.
     */
    public void getNationalBoardInfo() {
        super.getBoardInfo(); // Display general board info
        System.out.println("Recognition Date: " + recognitionDate);
        System.out.println("Approved By: " + approvedBy);
    }
}

/**
 * The SchoolBoard class represents a school-level educational board.
 * It extends the EducationBoard class to include additional details specific to school boards.
 */
class SchoolBoard extends EducationBoard {
    private String associatedMinistry; // Ministry associated with the school board
    private String rules;              // Rules governing the school board

    /**
     * Constructor to initialize the SchoolBoard with its specific attributes.
     *
     * @param name                    The name of the school board
     * @param establishedDate         The date the board was established
     * @param resolutionNumber        The resolution number for the board's establishment
     * @param gazetteNotificationDate The date the board was notified in the gazette
     * @param associatedMinistry      The ministry associated with the board
     * @param rules                   The rules governing the board
     */
    public SchoolBoard(String name, String establishedDate, String resolutionNumber, String gazetteNotificationDate, String associatedMinistry, String rules) {
        super(name, establishedDate, resolutionNumber, gazetteNotificationDate);
        this.associatedMinistry = associatedMinistry;
        this.rules = rules;
    }

    /**
     * Gets the ministry associated with the school board.
     *
     * @return The associated ministry
     */
    public String getAssociatedMinistry() {
        return associatedMinistry;
    }

    /**
     * Gets the rules governing the school board.
     *
     * @return The rules of the board
     */
    public String getRules() {
        return rules;
    }

    /**
     * Displays the information specific to the school board including inherited information.
     */
    public void getSchoolBoardInfo() {
        super.getBoardInfo(); // Display general board info
        System.out.println("Associated Ministry: " + associatedMinistry);
        System.out.println("Rules: " + rules);
    }
}

/**
 * The Education class is the entry point of the application.
 * It allows users to choose between displaying information about a National Board or a School Board.
 */
public class Education {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt the user to choose an education board
        System.out.println("Choose an education board:");
        System.out.println("1. National Board");
        System.out.println("2. School Board");

        // Read user choice
        System.out.print("Enter your choice (1 or 2): ");
        int choice = scanner.nextInt();

        // Display information based on user choice
        switch (choice) {
            case 1:
                // Create an instance of NationalBoard and display its information
                NationalBoard cbse = new NationalBoard("Central Board of Secondary Education (CBSE)", "01.07.1929", "F-115-R/28", "11.11.1929", "20.10.1990", "Ministry of Education");
                cbse.getNationalBoardInfo();
                break;
            case 2:
                // Create an instance of SchoolBoard and display its information
                SchoolBoard msrvvp = new SchoolBoard("Maharshi Sandipani Rashtriya Veda Sanskrit Shiksha Board, Ujjain", "08.08.2022", "Rule 14(iv) (f)", "25.01.2023", "Department of Higher Education", "MoA of MSRVVP");
                msrvvp.getSchoolBoardInfo();
                break;

            default:
                // Handle invalid user choice
                System.out.println("Invalid choice. Please enter either 1 or 2.");
        }
        scanner.close(); // Close the scanner
    }
}
