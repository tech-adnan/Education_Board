#include <iostream>
#include <string>

using namespace std;

class EducationBoard {
protected:
    string name;
    string establishedDate;
    string resolutionNumber;
    string gazetteNotificationDate;

public:
    EducationBoard(string name, string establishedDate, string resolutionNumber, string gazetteNotificationDate) {
        this->name = name;
        this->establishedDate = establishedDate;
        this->resolutionNumber = resolutionNumber;
        this->gazetteNotificationDate = gazetteNotificationDate;
    }

    void getBoardInfo() {
        cout << "Name: " << name << endl;
        cout << "Established Date: " << establishedDate << endl;
        cout << "Resolution Number: " << resolutionNumber << endl;
        cout << "Gazette Notification Date: " << gazetteNotificationDate << endl;
    }
};

class NationalBoard : public EducationBoard {
private:
    string recognitionDate;
    string approvedBy;

public:
    NationalBoard(string name, string establishedDate, string resolutionNumber, string gazetteNotificationDate, string recognitionDate, string approvedBy)
        : EducationBoard(name, establishedDate, resolutionNumber, gazetteNotificationDate) {
        this->recognitionDate = recognitionDate;
        this->approvedBy = approvedBy;
    }

    void getNationalBoardInfo() {
        getBoardInfo();
        cout << "Recognition Date: " << recognitionDate << endl;
        cout << "Approved By: " << approvedBy << endl;
    }
};

class SchoolBoard : public EducationBoard {
private:
    string associatedMinistry;
    string rules;

public:
    SchoolBoard(string name, string establishedDate, string resolutionNumber, string gazetteNotificationDate, string associatedMinistry, string rules)
        : EducationBoard(name, establishedDate, resolutionNumber, gazetteNotificationDate) {
        this->associatedMinistry = associatedMinistry;
        this->rules = rules;
    }

    void getSchoolBoardInfo() {
        getBoardInfo();
        cout << "Associated Ministry: " << associatedMinistry << endl;
        cout << "Rules: " << rules << endl;
    }
};

int main() {
    cout << "Choose an education board:" << endl;
    cout << "1. National Board" << endl;
    cout << "2. School Board" << endl;

    int choice;
    cout << "Enter your choice (1 or 2): ";
    cin >> choice;

    if (choice == 1) {
        NationalBoard cbse(
            "Central Board of Secondary Education (CBSE)",
            "01.07.1929",
            "F-115-R/28",
            "11.11.1929",
            "20.10.1990",
            "Ministry of Education"
        );
        cbse.getNationalBoardInfo();
    } else if (choice == 2) {
        SchoolBoard msrvvp(
            "Maharshi Sandipani Rashtriya Veda Sanskrit Shiksha Board, Ujjain",
            "08.08.2022",
            "Rule 14(iv) (f)",
            "25.01.2023",
            "Department of Higher Education",
            "MoA of MSRVVP"
        );
        msrvvp.getSchoolBoardInfo();
    } else {
        cout << "Invalid choice. Please enter either 1 or 2." << endl;
    }

    return 0;
}